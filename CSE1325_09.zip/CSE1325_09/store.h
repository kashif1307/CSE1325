#ifndef __STORE_H
#define __STORE_H
#include "product.h"
#include <vector>
#include <iostream>
#include <ostream>

class Store
{
public:

	//Store(Product product);
	Store(std::string store_name);
	std::string name();
	void add_product(Product* product);
	int number_of_products();
	std::string product_to_string(int product);
	std::string show_all3();
	std::string show_all();

	friend std::ostream& operator<<(std::ostream& ost, const Store& store);
	~Store();


private:
	std::string _name;
	std::vector<Product*> _products;
	





};

#endif 
