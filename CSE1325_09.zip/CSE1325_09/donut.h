#ifndef __DONUT_H
#define __DONUT_H
#include "product.h"

enum Frosting {Unfrosted, Chocolate_top, Vanilla_top, Strawberry_top};
enum Filling {Unfilled, Creme, Bavarian,Strawberry};

class Donut : public Product{
public:
	Donut(std::string name, double price, double cost, Frosting frosting, bool sprinkles, Filling filling);

	std::string to_string();
	std::string filling_to_string();
	std::string frosting_to_string();
	
protected:
	bool _sprinkles;
	Frosting _frosting;
	Filling _filling;

};


#endif 
