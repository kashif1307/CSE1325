#include "donut.h"

#include<iostream>
#include<string>

Donut::Donut(std::string name, double price, double cost, Frosting frosting, bool sprinkles, Filling filling) : Product(name,price,cost)
{
	_frosting = frosting;
	_sprinkles = sprinkles;
	_filling = filling;


}


std::string Donut::filling_to_string() {
	if (_filling == Filling::Unfilled) return "Unfilled";
	else if (_filling == Filling::Creme) return "Creme";
	else if (_filling == Filling::Bavarian) return "Bavarian";
	else if (_filling == Filling::Strawberry) return "Strawberry";
}

std::string Donut::frosting_to_string() {
	if (_frosting == Frosting::Unfrosted) return "Unfrosted";
	else if (_frosting == Frosting::Chocolate_top) return "Chocolate_top";
	else if (_frosting == Frosting::Vanilla_top) return "Vanilla_top";
	else if (_frosting == Frosting::Strawberry_top) return "Strawberry_top";
}


std::string Donut::to_string()
{

	std::string donutstring = Product::to_string();
	std::string sprinkle;
	if (_sprinkles = true)
	{
		sprinkle = "Sprinkle";
	}
	else
	{
		sprinkle = "No Sprinkle";
		
	}
	
	//return _name + ' ' + std::to_string(_price) + ' ' + std::to_string(_cost) + ' ' + sprinkle + ' ' + filling_to_string() + ' ' + frosting_to_string();

	return donutstring +' ' + sprinkle + ' ' + filling_to_string() + ' ' + frosting_to_string() + "\n";
}
