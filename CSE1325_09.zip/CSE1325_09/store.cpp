#include "store.h"
#include <iostream>
#include <string>
#include <vector>
#include <ostream>

//Store::Store() : Store(Product{}) { }


Store::Store(std::string store_name)
{
	//std::cout << "Store created\n";
	_name = store_name;
}

Store::~Store()
{
	for (auto p : _products)
	{
		delete p;
	}
}
std::string Store::name()
{
	return _name;
}

void Store::add_product(Product* product)
{
//	 Product* p = new Product();
	_products.push_back(product);

}

int Store::number_of_products()
{
	return _products.size();

}

std::string Store::product_to_string(int product)
{
	return _products[product]->to_string();
}

/*
std::string Store::show_all()
{
	std::string result = "";
	for (int i = 0; i < number_of_products(); i++)
	{
		result = result + " " + product_to_string(i);
	}
	return result;
}
*/
std::string Store::show_all()
{
	std::string result = "";
	//std::cout << "Num of product = " << number_of_products() << "\n";
	for (auto p : _products)
	{
		result += p->to_string();
	}

	return result;
}


std::ostream& operator<<(std::ostream& ost, const Store& store) 
{
	//ost << vehicle.to_string();
		for (auto p : store._products)
			ost << store._name << ' ' << p << std::endl;
	return ost;
}


std::string Store::show_all3()
{
	std::cout << this;
}
