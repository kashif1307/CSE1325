#include "java.h"
#include <iostream>
#include<vector>
#include<string>

Java::Java(std::string name, double price, double cost, int darkness) : Product(name, price, cost) {

	_darkness = darkness;

}

void Java::add_shot(Shot shot)
{
	_shots.push_back(shot);

}

std::string Java::to_string()
{

	std::string javastring = Product::to_string();

	//std::vector<std::string> v{ "Hello, ", "Cruel ", "World!" };
	std::string result;
	//None, Chocolate, Vanilla, Peppermint, Hazelnut};
	for (auto const& i : _shots) 
	{ 
		switch (i)
		{
			case 0:
				result += "None";
				break;
			case 1:
				result += "Chocolate";
				break;
			case 2:
				result += "Vanilla";
				break;
			case 3:
				result += "Peppermint";
				break;
			case 4:
				result += "Hazelnut";
				break;
			default:
				result += "Error";
		}
	}
	//std::cout << result; // Will print "Hello, Cruel World!"


	//for (auto i : _shots)
	//{


	//}

	return javastring + ' ' + result + ' ' + std::to_string (_darkness) + " \n";
}

