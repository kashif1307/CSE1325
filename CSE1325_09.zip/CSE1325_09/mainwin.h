#ifndef __MAINWIN_H
#define __MAINWIN_H

#include "store.h"
#include <gtkmm.h>
#include "java.h"
#include "donut.h"

class Mainwin : public Gtk::Window
{
public:
	Mainwin();
	virtual ~Mainwin();
protected:
	//void on_new_rental_site_click(); // Create a new rental site
	//void on_file_open_click();       // Open a rental site
	//void on_file_save_click();       // Save a rental site
	//void on_file_save_as_click();    // Save as rental site
	//void on_new_vehicle_click();     // Create a new vehicle
	//void on_list_vehicles_click();   // List all vehicles
	//void on_rent_vehicle_click();    // Rent a vehicle
	//void on_return_vehicle_click();  // Return a vehicle
	//void on_new_renter_click();      // Create a new renter
	//void on_list_renters_click();    // List all renters
	//void on_help_click();            // Display help
	//void on_about_click();           // Display About dialog
	void on_quit_click();            // Exit the program
	void on_view_all_click();
	void on_create_coffee_click();
	void on_create_donut_click();
private:
	Store _store;               // Update display
	Gtk::Label *msg;       
	Gtk::MenuItem* menuitem_new_coffee;// Status message display
	Gtk::MenuItem* menuitem_new_donut; 

/* Saved from baseline for upcoming toolbar
		Gtk::ToolButton *rent_vehicle;        // Button to select 1 stick
		Gtk::Image *rent_on_image;            //   Image when active
		Gtk::Image *rent_off_image;           //   Image when inactive
		Gtk::ToolButton *return_vehicle;      // Button to select 2 sticks
		Gtk::Image *return_on_image;
		Gtk::Image *return_off_image;
*/
};
#endif 

