#include "mainwin.h"
#include "dialogs.h"
#include "store.h"



	Mainwin::Mainwin() :_store{Store{"Parks Mall Jade"} } {

	// Provide parent window to dialogs to avoid discouraging warnings
	Dialogs::set_window(*this);

	// /////////////////
	// G U I   S E T U P
	// /////////////////

	set_default_size(800, 600);

	// Put a vertical box container as the Window contents
	Gtk::Box *vbox = Gtk::manage(new Gtk::Box(Gtk::ORIENTATION_VERTICAL, 0));
	add(*vbox);

	// ///////
	// M E N U
	// Add a menu bar as the top item in the vertical box
	Gtk::MenuBar *menubar = Gtk::manage(new Gtk::MenuBar());
	vbox->pack_start(*menubar, Gtk::PACK_SHRINK, 0);

	//     F I L E
	// Create a File menu and add to the menu bar
	Gtk::MenuItem *menuitem_file = Gtk::manage(new Gtk::MenuItem("_File", true));
	menubar->append(*menuitem_file);
	Gtk::Menu *filemenu = Gtk::manage(new Gtk::Menu());
	menuitem_file->set_submenu(*filemenu);

	//         N E W   R E N T A L   S I T E
	// Append New to the File menu
	//Gtk::MenuItem *menuitem_new = Gtk::manage(new Gtk::MenuItem("_New", true));
	//menuitem_new->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_new_rental_site_click));
	//filemenu->append(*menuitem_new);

	//         O P E N   R E N T A L   S I T E
	// Append Open to the File menu
	//Gtk::MenuItem *menuitem_open = Gtk::manage(new Gtk::MenuItem("_Open", true));
	//menuitem_open->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_file_open_click));
	//filemenu->append(*menuitem_open);

	//         S A V E   R E N T A L   S I T E
	// Append Save to the File menu
	//Gtk::MenuItem *menuitem_save = Gtk::manage(new Gtk::MenuItem("_Save", true));
	//menuitem_save->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_file_save_click));
	//filemenu->append(*menuitem_save);

	//         S A V E   A S   R E N T A L   S I T E
	// Append New to the File menu
	//Gtk::MenuItem *menuitem_save_as = Gtk::manage(new Gtk::MenuItem("Save _As", true));
	//menuitem_save_as->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_file_save_as_click));
	//filemenu->append(*menuitem_save_as);

	//         Q U I T
	// Append Quit to the File menu
	Gtk::MenuItem *menuitem_quit = Gtk::manage(new Gtk::MenuItem("_Quit", true));
	menuitem_quit->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_quit_click));
	filemenu->append(*menuitem_quit);

	//    VIEW
	// Create a VIEW menu and add to the menu bar
	Gtk::MenuItem *menuitem_view = Gtk::manage(new Gtk::MenuItem("_View", true));
	menubar->append(*menuitem_view);
	Gtk::Menu *viewmenu = Gtk::manage(new Gtk::Menu());
	menuitem_view->set_submenu(*viewmenu);

	//           N E W   V E H I C L E
	// Append New Vehicle to the Vehicle menu
	//Gtk::MenuItem *menuitem_new_vehicle = Gtk::manage(new Gtk::MenuItem("_New", true));
	//menuitem_new_vehicle->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_new_vehicle_click));
	//vehiclemenu->append(*menuitem_new_vehicle);

	//           L I S T   P R O D U C T S
	// Append New Vehicle to the Vehicle menu
	Gtk::MenuItem *menuitem_list_products = Gtk::manage(new Gtk::MenuItem("_Products", true));
	menuitem_list_products->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_view_all_click));
	viewmenu->append(*menuitem_list_products);

	//           R E N T   V E H I C L E
	// Append New Vehicle to the Vehicle menu
	//Gtk::MenuItem *menuitem_rent_vehicle = Gtk::manage(new Gtk::MenuItem("_Rent", true));
	///menuitem_rent_vehicle->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_rent_vehicle_click));
	//vehiclemenu->append(*menuitem_rent_vehicle);

	//           R E T U R N   V E H I C L E
	// Append New Vehicle to the Vehicle menu
	//Gtk::MenuItem *menuitem_return_vehicle = Gtk::manage(new Gtk::MenuItem("R_eturn", true));
	//menuitem_return_vehicle->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_return_vehicle_click));
	//vehiclemenu->append(*menuitem_return_vehicle);

	//      C R E A T E
	// Create a create menu and add to the menu bar
	Gtk::MenuItem *menuitem_create = Gtk::manage(new Gtk::MenuItem("_Create", true));
	menubar->append(*menuitem_create);
	Gtk::Menu *createmenu = Gtk::manage(new Gtk::Menu());
	menuitem_create->set_submenu(*createmenu);

	//           C O F F E E
	// Append Coffee to the create menu
	Gtk::MenuItem *menuitem_new_coffee = Gtk::manage(new Gtk::MenuItem("_Coffee", true));
	menuitem_new_coffee->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_create_coffee_click));
	createmenu->append(*menuitem_new_coffee);

	//           D O N U T S
	// Append Donuts to the create menu

	// Append Coffee to the create menu
	Gtk::MenuItem *menuitem_new_donut = Gtk::manage(new Gtk::MenuItem("_Donut", true));
	menuitem_new_donut->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_create_donut_click));
	createmenu->append(*menuitem_new_donut);
	//Gtk::MenuItem *menuitem_new_donuts = Gtk::manage(new Gtk::MenuItem("_Donuts", true));
	//menuitem_list_renters->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_list_renters_click));
	//rentermenu->append(*menuitem_list_renters);

	//     H E L P
	// Create a Help menu and add to the menu bar
//	Gtk::MenuItem *menuitem_help = Gtk::manage(new Gtk::MenuItem("_Help", true));
//	menubar->append(*menuitem_help);
	///Gtk::Menu *helpmenu = Gtk::manage(new Gtk::Menu());
	//menuitem_help->set_submenu(*helpmenu);

	//           H E L P
	// Append Help to the Help menu
/*	Gtk::MenuItem *menuitem_help_ = Gtk::manage(new Gtk::MenuItem("_Help", true));
	menuitem_help_->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_help_click));
	helpmenu->append(*menuitem_help_);

	//           A B O U T
	// Append About to the Help menu
	Gtk::MenuItem *menuitem_about = Gtk::manage(new Gtk::MenuItem("_About", true));
	menuitem_about->signal_activate().connect(sigc::mem_fun(*this, &Mainwin::on_about_click));
	helpmenu->append(*menuitem_about);
	/*
		// /////////////
		// T O O L B A R
		// Add a toolbar to the vertical box below the menu
		Gtk::Toolbar *toolbar = Gtk::manage(new Gtk::Toolbar);
		vbox->add(*toolbar);

		//     N E W   G A M E
		// Add a new game icon
		Gtk::ToolButton *new_game_button = Gtk::manage(new Gtk::ToolButton(Gtk::Stock::NEW));
		new_game_button->set_tooltip_markup("Create a new name, discarding any in progress");
		new_game_button->signal_clicked().connect(sigc::mem_fun(*this, &Mainwin::on_new_game_click));
		toolbar->append(*new_game_button);

		//     O N E   S T I C K
		// Add a icon for taking one stick
		button1_on_image = Gtk::manage(new Gtk::Image{"button1_on.png"});
		button1_off_image = Gtk::manage(new Gtk::Image{"button1_off.png"});
		button1 = Gtk::manage(new Gtk::ToolButton(*button1_on_image));
		button1->set_tooltip_markup("Select one stick");
		button1->signal_clicked().connect(sigc::mem_fun(*this, &Mainwin::on_button1_click));
		toolbar->append(*button1);

		//     T W O   S T I C K S
		// Add a icon for taking two sticks
		button2_on_image = Gtk::manage(new Gtk::Image{"button2_on.png"});
		button2_off_image = Gtk::manage(new Gtk::Image{"button2_off.png"});
		button2 = Gtk::manage(new Gtk::ToolButton(*button2_on_image));
		button2->set_tooltip_markup("Select two sticks");
		button2->signal_clicked().connect(sigc::mem_fun(*this, &Mainwin::on_button2_click));
		toolbar->append(*button2);

		//     T H R E E   S T I C K S
		// Add a icon for taking three sticks
		button3_on_image = Gtk::manage(new Gtk::Image{"button3_on.png"});
		button3_off_image = Gtk::manage(new Gtk::Image{"button3_off.png"});
		button3 = Gtk::manage(new Gtk::ToolButton(*button3_on_image));
		button3->set_tooltip_markup("Select three sticks");
		button3->signal_clicked().connect(sigc::mem_fun(*this, &Mainwin::on_button3_click));
		toolbar->append(*button3);

		//     C O M P U T E R   P L A Y E R
		// Add a toggle button to enable computer to play as Player 2
		Gtk::Image *robot_image = Gtk::manage(new Gtk::Image{"freepik_robot.png"});
		computer_player = Gtk::manage(new Gtk::ToggleToolButton(*robot_image));
		computer_player->set_tooltip_markup("Enable for computer to be Player 2");
		computer_player->signal_clicked().connect(sigc::mem_fun(*this, &Mainwin::on_computer_player_click));
		Gtk::SeparatorToolItem *sep1 = Gtk::manage(new Gtk::SeparatorToolItem());
		toolbar->append(*sep1);
		toolbar->append(*computer_player);

		//     Q U I T
		// Add a icon for quitting
		Gtk::ToolButton *quit_button = Gtk::manage(new Gtk::ToolButton(Gtk::Stock::QUIT));
		quit_button->set_tooltip_markup("Exit game");
		quit_button->signal_clicked().connect(sigc::mem_fun(*this, &Mainwin::on_quit_click));
		Gtk::SeparatorToolItem *sep = Gtk::manage(new Gtk::SeparatorToolItem());
		sep->set_expand(true);  // The expanding sep forces the Quit button to the right
		toolbar->append(*sep);
		toolbar->append(*quit_button);

		// S T I C K S   D I S P L A Y
		// Provide a text entry box to show the remaining sticks
		sticks = Gtk::manage(new Gtk::Label());
		// sticks->set_has_frame(false);
		sticks->set_hexpand(true);
		sticks->set_vexpand(true);
		vbox->add(*sticks);
	*/
	// S T A T U S   B A R   D I S P L A Y
	// Provide a status bar for program messages
//	msg = Gtk::manage(new Gtk::Label());
//	msg->set_hexpand(true);
	//vbox->add(*msg);

	// Make the box and everything in it visible
	vbox->show_all();
}

Mainwin::~Mainwin() { }

// /////////////////
// C A L L B A C K S
// /////////////////

//void Mainwin::on_new_rental_site_click() { // Create a new rental site
	//_controller.execute_cmd(18);
//}


void Mainwin::on_view_all_click()
{
	//std::cout << _store;
	//_store.show_all3();
	Dialogs::message(_store.show_all(), "All Products");
//	Dialogs::message(_store.show_all(), "Products");
}



void Mainwin::on_create_coffee_click()
{

	Java* java = new Java("Iced Caramel", 3.49, 1.20, 3);
	java->add_shot(Chocolate);
	_store.add_product(java);

//	free(java);


}

void Mainwin::on_create_donut_click()
{

	Donut* donut = new Donut("Boston Creme", 2.00, 5.00, Chocolate_top, true, Creme);
	
	_store.add_product(donut);

	//free(donut);


}


/*void Mainwin::on_file_open_click() {       // Open a rental site
	_controller.execute_cmd(8);
}

void Mainwin::on_file_save_click() {       // Save a rental site
	_controller.execute_cmd(17);
}

void Mainwin::on_file_save_as_click() {    // Save as rental site
	_controller.execute_cmd(7);
}

void Mainwin::on_new_vehicle_click() {     // Create a new vehicle
	_controller.execute_cmd(1);
}

void Mainwin::on_list_vehicles_click() {   // List all vehicles
	_controller.execute_cmd(2);
}

void Mainwin::on_rent_vehicle_click() {    // Rent a vehicle
	_controller.execute_cmd(3);
}

void Mainwin::on_return_vehicle_click() {  // Return a vehicle
	_controller.execute_cmd(4);
}

*/
/*void Mainwin::on_new_renter_click() {      // Create a new renter
	_controller.execute_cmd(5);
}

void Mainwin::on_list_renters_click() {    // List all renters
	_controller.execute_cmd(6);
}

void Mainwin::on_help_click() {            // Display help
	_controller.execute_cmd(9);
}

void Mainwin::on_about_click() {
	Glib::ustring s = "<span size='24000' weight='bold'>Rental Vehicle Management System</span>\n<span size='large'>Copyright 2018 by George F. Rice</span>\n<span size='small'>Licensed under Creative Commons Attribution 4.0 International</span>";
	Gtk::MessageDialog dlg(*this, s, true, Gtk::MESSAGE_INFO, Gtk::BUTTONS_OK, true);
	dlg.run();
}
*/
void Mainwin::on_quit_click() {      // Exit the program
	hide();
}

// /////////////////
// U T I L I T I E S
// /////////////////


